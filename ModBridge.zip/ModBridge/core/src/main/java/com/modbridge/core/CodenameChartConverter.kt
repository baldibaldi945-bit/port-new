package com.modbridge.core

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.floor
import kotlin.math.max

/** Converts Codename Engine's millisecond strumLine notes into Psych Engine sectionNotes. */
object CodenameChartConverter {
    fun convert(chartText: String, metaText: String, songFolder: String, difficulty: String): Pair<String, List<ConversionWarning>> {
        val chart = JSONObject(chartText)
        val meta = JSONObject(metaText)
        val bpm = meta.optDouble("bpm", 100.0).takeIf { it > 0 } ?: 100.0
        val stepMs = 60000.0 / bpm / 4.0
        val strumLines = chart.optJSONArray("strumLines") ?: JSONArray()
        val warnings = mutableListOf<ConversionWarning>()
        if (strumLines.length() > 2) warnings += ConversionWarning("WARNING", "songs/$songFolder", "More than two strum lines; extra lines are folded into the nearest side.")

        val notes = mutableListOf<Triple<Double, Int, Double>>() // time, lane, sustain
        for (lineIndex in 0 until strumLines.length()) {
            val line = strumLines.optJSONObject(lineIndex) ?: continue
            val position = line.optString("position", "")
            val isPlayer = when (position.lowercase()) {
                "bf", "boyfriend", "player" -> true
                "dad", "opponent" -> false
                else -> lineIndex == 1
            }
            val laneCount = max(1, line.optInt("keyCount", 4))
            val lineNotes = line.optJSONArray("notes") ?: JSONArray()
            for (i in 0 until lineNotes.length()) {
                val n = lineNotes.optJSONObject(i) ?: continue
                val lane = n.optInt("id", 0).coerceIn(0, laneCount - 1) + if (isPlayer) 4 else 0
                val time = n.optDouble("time", 0.0)
                val sustain = n.optDouble("sLen", 0.0).coerceAtLeast(0.0)
                notes += Triple(time, lane, sustain)
            }
        }
        notes.sortBy { it.first }

        val events = chart.optJSONArray("events") ?: JSONArray()
        if (events.length() > 0) warnings += ConversionWarning("WARNING", "songs/$songFolder/charts/$difficulty.json", "Codename chart events are not yet fully translated; see conversion-report.txt. Notes are converted.")
        if (chart.optBoolean("codenameChart", false).not()) warnings += ConversionWarning("INFO", "songs/$songFolder/charts/$difficulty.json", "Chart does not set codenameChart=true; converted using the observed strumLines schema.")

        val sections = JSONArray()
        val maxTime = notes.maxOfOrNull { it.first + it.third } ?: 0.0
        val sectionCount = max(1, floor(maxTime / (stepMs * 16)).toInt() + 1)
        var cursor = 0
        for (sectionIndex in 0 until sectionCount) {
            val sectionStart = sectionIndex * stepMs * 16
            val sectionEnd = sectionStart + stepMs * 16
            val sectionNotes = JSONArray()
            var playerNotes = 0
            var opponentNotes = 0
            while (cursor < notes.size && notes[cursor].first < sectionEnd) {
                val note = notes[cursor]
                if (note.first >= sectionStart) {
                    sectionNotes.put(JSONArray().put(note.first).put(note.second).put(note.third).put(""))
                    if (note.second >= 4) playerNotes++ else opponentNotes++
                }
                cursor++
            }
            sections.put(JSONObject()
                .put("sectionNotes", sectionNotes)
                .put("lengthInSteps", 16)
                .put("mustHitSection", playerNotes > opponentNotes)
                .put("altAnim", false)
                .put("gfSection", false)
                .put("changeBPM", false)
                .put("bpm", bpm))
        }
        val song = JSONObject()
            .put("song", meta.optString("displayName", songFolder))
            .put("notes", sections)
            .put("bpm", bpm)
            .put("needsVoices", meta.optBoolean("needsVoices", true))
            .put("speed", chart.optDouble("scrollSpeed", 1.0))
            .put("player1", "bf")
            .put("player2", "dad")
            .put("gfVersion", "gf")
            .put("stage", chart.optString("stage", "stage"))
            .put("validScore", true)
        val root = JSONObject().put("song", song)
        return root.toString(2) to warnings
    }
}
